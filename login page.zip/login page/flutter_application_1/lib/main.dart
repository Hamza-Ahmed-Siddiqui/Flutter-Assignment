import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text("login page"),
        ),
        body: login(),
      ),
    );
  }
}

class login extends StatefulWidget {
  const login({Key? key}) : super(key: key);

  @override
  _loginState createState() => _loginState();
}

class _loginState extends State<login> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        body: Center(
          child: Column(
            children: [
              Image.network(
                "https://cms-assets.tutsplus.com/uploads/users/34/syllabuses/816/preview_image/tutsplus-icon.png",
                height: 200,
                width: 150,
              ),
              SizedBox(
                height: 10,
              ),
              Container(
                width: 400,
                child: TextField(
                  decoration: const InputDecoration(
                      border: OutlineInputBorder(),
                      label: Text("Email"),
                      hintText: 'Enter Email'),
                ),
              ),
              SizedBox(
                height: 20,
              ),
              Container(
                width: 400,
                child: TextField(
                  decoration: const InputDecoration(
                      border: OutlineInputBorder(),
                      label: Text("Password"),
                      hintText: 'Enter Password'),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(15.0),
                child: ElevatedButton(onPressed: () {}, child: Text("Login")),
              ),
              Text("Sign in With Google"),
            ],
          ),
        ),
      ),
    );
  }
}
